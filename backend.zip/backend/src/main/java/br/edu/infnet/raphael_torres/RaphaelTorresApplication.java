package br.edu.infnet.raphael_torres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaphaelTorresApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaphaelTorresApplication.class, args);
		

	}

}
