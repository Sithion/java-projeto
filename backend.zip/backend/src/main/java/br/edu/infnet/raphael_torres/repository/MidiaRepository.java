package br.edu.infnet.raphael_torres.repository;

import org.springframework.stereotype.Repository;

import br.edu.infnet.raphael_torres.model.domain.Midia;
@Repository
public interface MidiaRepository extends BaseRepository<Midia> {
}
