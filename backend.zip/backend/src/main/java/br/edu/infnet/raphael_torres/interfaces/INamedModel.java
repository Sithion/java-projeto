package br.edu.infnet.raphael_torres.interfaces;

public interface INamedModel {
    public String getNome();
}
