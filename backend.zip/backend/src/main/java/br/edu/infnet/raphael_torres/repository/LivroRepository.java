package br.edu.infnet.raphael_torres.repository;

import org.springframework.stereotype.Repository;

import br.edu.infnet.raphael_torres.model.domain.midias.Livro;

@Repository
public interface LivroRepository extends BaseRepository<Livro> {
}
